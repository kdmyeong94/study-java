package interfaceobject;

public interface Action {
	
	public void pickup();
	
}
