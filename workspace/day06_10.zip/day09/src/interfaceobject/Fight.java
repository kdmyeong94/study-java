package interfaceobject;

public interface Fight {
	
	public void attack();
	
	public void shield();
	
}
