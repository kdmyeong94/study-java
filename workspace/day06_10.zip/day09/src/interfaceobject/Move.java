package interfaceobject;

public interface Move {

	public void walk();
	
	public void run();
	
	public void jump();
	
}
