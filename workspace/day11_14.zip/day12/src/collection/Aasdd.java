package collection;

public class Aasdd {

	public static void main(String[] args) {

		String a = "10";
		double b = 1.2345;
		float c = 1.2F;
		long d = 1;
		int e = 2;
		short f = 3;
		byte g = 4;
				
		System.out.println(a+b);
		System.out.println(a+c);
		System.out.println(a+d);
		System.out.println(a+e);
		System.out.println(a+f);
		System.out.println(a+g);
		
		System.out.println(g/b);
		
		System.out.println(a+a);
		
	}

}
