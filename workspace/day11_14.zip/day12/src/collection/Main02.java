package collection;

import java.util.ArrayList;
import java.util.List;

public class Main02 {

	public static void main(String[] args) {
		
		List<Integer> numberList = new ArrayList<>();
		
//		데이터 추가
		numberList.add(10);
		numberList.add(20);
		numberList.add(30);
		numberList.add(40);
		numberList.add(50);
		numberList.add(60);
		numberList.add(70);
		numberList.add(80);
		numberList.add(90);
		
//		추가된 데이터의 수량
		int count = numberList.size();
		System.out.println("크기 : " + count);
		
//		5번째 요소의 값 얻기
		int value = numberList.get(4);
		System.out.println("5번째 : " + value);
		
//		5번째 요소의 값 삭제
		numberList.remove(4);
		
		count = numberList.size();
		System.out.println("크기 : " + count);

//		5번째 요소의 값 다시 얻기
		value = numberList.get(4);
		System.out.println("5번째 : " + value);
		
//		데이터 전체 삭제
		numberList.clear();
		count = numberList.size();
		System.out.println(count);
		
		
		
		
	}
}
